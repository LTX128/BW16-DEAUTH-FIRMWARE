# RTL8720dn-WiFi-Packet-Injection
Send raw 802.11 WiFi frames using an RTL8720dn

# DISCLAIMER
This tool has been made for educational and testing purposes only. Any misuse or illegal activities conducted with the tool are strictly prohibited. I am **not** responsible for any consequences arising from the use of the tool, which is done at your own risk.

## Notes
This repository is now intended to be used as a Git submodule.
The testing code has been removed. Documentation can be found in `packet-injection.cpp`.
The story on how I have been able to discover these possibilities is available on my [Blog](https://tesa-klebeband.github.io).

## License
All files within this repo are released under the GNU GPL V3 License as per the LICENSE file stored in the root of this repo.
